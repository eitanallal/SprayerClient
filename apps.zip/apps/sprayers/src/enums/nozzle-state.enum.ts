export enum NozzleState {
  ON = 'ON',
  OFF = 'OFF',
  AUTO = 'AUTO',
}
