export type HealthDataType = {
  time_since_last_GPS_data: number | null;
};
